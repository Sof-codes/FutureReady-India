import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["project"] == "FutureReady India"

def test_occupations_summary():
    response = client.get("/api/occupations")
    assert response.status_code == 200
    data = response.json()
    assert len(data) > 0
    assert "occupation" in data[0]

def test_research_statistics():
    response = client.get("/api/research/statistics")
    assert response.status_code == 200
    data = response.json()
    assert data["total_jobs_analyzed"] >= 40
    assert data["total_sectors"] >= 8

def test_assessment_questions():
    response = client.get("/api/assessment/questions")
    assert response.status_code == 200
    questions = response.json()
    assert len(questions) >= 5

def test_recommendations_engine():
    payload = {
        "degree": "BCA",
        "graduation_year": 2024,
        "field_of_study": "Computer Science",
        "answers": {"q1": 75, "q2": 70, "q3": 80, "q4": 80, "q5": 75, "q6": 80}
    }
    response = client.post("/api/recommendations", json=payload)
    assert response.status_code == 200
    res = response.json()
    assert "profile" in res
    assert "top_matches" in res
    assert "roadmap" in res
    assert res["profile"]["overall_readiness_score"] > 50

def test_chatbot_assistant():
    payload = {"message": "Why is SQL recommended for me?"}
    response = client.post("/api/chatbot", json=payload)
    assert response.status_code == 200
    res = response.json()
    assert "sql" in res["answer"].lower()
    assert len(res["citations"]) > 0
