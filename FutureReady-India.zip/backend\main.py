from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routers import occupations, research, assessment, recommendations, chatbot

app = FastAPI(
    title="FutureReady India API",
    description="Research & Technology Intelligence Engine on AI, Skills & Entry-Level Employment in India",
    version="1.0.0"
)

# Enable CORS for local Vite dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(occupations.router)
app.include_router(research.router)
app.include_router(assessment.router)
app.include_router(recommendations.router)
app.include_router(chatbot.router)

@app.get("/")
def read_root():
    return {
        "status": "online",
        "project": "FutureReady India",
        "vision": "Understanding AI, Skills & Entry-Level Employment",
        "docs_url": "/docs"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
